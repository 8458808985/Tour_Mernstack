export const progressBar = [90, 50, 40];
export const tab1 = ["Art and culture", "Beaches", "Adventure travel"];
export const tab2 = ["item1", "item2", "item3"];

export const tabContent = [
  [
    "Pharetra nulla ullamcorper sit lectus. Fermentum mauris pellentesque nec nibh sed et, vel diam, massa. Placerat quis vel fames interdum urna lobortis sagittis sed pretium. Morbi sed arcu proin quis tortor non risus.",
    "Elementum lectus a porta commodo suspendisse arcu, aliquam lectus faucibus",
  ],
  [
    "Vivamus ornare risus at turpis consectetur. Ut tempus justo eget libero interdum, sed suscipit purus imperdiet. Aenean nec diam quis libero suscipit ullamcorper. Quisque vestibulum ligula in velit efficitur, ac .",
    "Suspendisse ullamcorper velit ac tristique. Vestibulum faucibus sapien in nibh sollicitudin, eget commodo",
  ],
  [
    "Suspendisse rutrum turpis at ipsum ultricies. Nulla facilisi. Maecenas eget libero in metus convallis fringilla. Fusce sodales purus sed felis consectetur, vel ullamcorper odio cursus. Curabitur eleifend metus nec .",
    "ornare risus at turpis consectetur. Ut tempus justo eget libero interdum, sed suscipit purus imperdiet.",
  ],
];

export const ddoptions = [
  { id: 1, value: "banking", label: "Banking" },
  { id: 2, value: "digital & creative", label: "Digital & Creative" },
  { id: 3, value: "retail", label: "Retail" },
  { id: 4, value: "designer", label: "Designer" },
  { id: 5, value: "developer", label: "Developer" },
];

export const requirements = [
  "You will need a copy of Adobe XD 2019 or above. A free trial can be downloaded from Adobe.",
  "No previous design experience is needed.",
  "No previous Adobe XD skills are needed.",
];

export const learningContents = [
  "Beverages, drinking water, morning tea and buffet lunch",
  "Local taxes",
  "Hotel pickup and drop-off by air-conditioned minivan",
  "InsuranceTransfer to a private pier",
  "Soft drinks",
  "Tour Guide",
];
