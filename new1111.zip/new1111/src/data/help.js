export const sections = [
  {
    imgSrc: "/img/icons/6/1.svg",
    title: "Booking your activity",
    content: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    imgSrc: "/img/icons/6/2.svg",
    title: "Payment & receipts",
    content: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    imgSrc: "/img/icons/6/3.svg",
    title: "Booking changes & refunds",
    content: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    imgSrc: "/img/icons/6/4.svg",
    title: "Promo codes & credits",
    content: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    imgSrc: "/img/icons/6/5.svg",
    title: "On the participation day",
    content: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    imgSrc: "/img/icons/6/6.svg",
    title: "Value Packs",
    content: "Lorem ipsum is placeholder text commonly used in site.",
  },
];
