export const articles = [
  {
    id: 1,
    imgSrc: "/img/blogCards/1/1.png",
    badge: "Trips",
    date: "April 06 2023",
    author: "Ali Tufan",
    title: "Kenya vs Tanzania Safari: The Better African Safari Experience",
  },
  {
    id: 2,
    imgSrc: "/img/blogCards/1/2.png",
    badge: "Trips",
    date: "April 06 2023",
    author: "Ali Tufan",
    title: "Kenya vs Tanzania Safari: The Better African Safari Experience",
  },
  {
    id: 3,
    imgSrc: "/img/blogCards/1/3.png",
    badge: "Trips",
    date: "April 06 2023",
    author: "Ali Tufan",
    title: "Kenya vs Tanzania Safari: The Better African Safari Experience",
  },
];
