export const teamData = [
  {
    id: 1,
    name: "Arlene McCoy",
    position: "Program Manager",
    imgPath: "/img/team/1/1.jpg",
  },
  {
    id: 2,
    name: "Esther Howard",
    position: "Account Executive",
    imgPath: "/img/team/1/2.jpg",
  },
  {
    id: 3,
    name: "Cody Fisher",
    position: "Quality Control Coordinator",
    imgPath: "/img/team/1/3.jpg",
  },
  {
    id: 4,
    name: "Bessie Cooper",
    position: "Marketing Consultant",
    imgPath: "/img/team/1/4.jpg",
  },
  {
    id: 5,
    name: "Guy Hawkins",
    position: "Copywriter",
    imgPath: "/img/team/1/5.jpg",
  },
];
