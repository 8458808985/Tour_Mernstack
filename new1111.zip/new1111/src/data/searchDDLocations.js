export const locations = [
  { id: 1, choice: "Europe", type: "Continent" },
  { id: 2, choice: "France", type: "Country" },
  { id: 3, choice: "London", type: "Destinations" },
  { id: 4, choice: "Asia", type: "Continent" },
  { id: 5, choice: "United States", type: "Country" },
  { id: 6, choice: "Tokio", type: "Destinations" },
  { id: 7, choice: "Africa", type: "Continent" },
  { id: 8, choice: "New Zealand", type: "Country" },
];
